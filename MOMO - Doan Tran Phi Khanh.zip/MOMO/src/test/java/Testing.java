import com.shield.entity.Bill;
import com.shield.entity.User;
import com.shield.services.BillService;
import com.shield.services.IBillService;
import com.shield.services.IUserService;
import com.shield.services.UserService;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;


public class Testing {

    private IBillService billService;
    private IUserService userService;

    List<Bill> bills;
    private User user;

    @BeforeEach
    void setUp() {
        bills = new ArrayList<>();
        billService = new BillService(bills);
        user = new User();
        userService = new UserService(user);

        IUserService userService = new UserService(user);
    }

    @Test
     void shouldIncreaseUserAmount_WhenValidFundIsAdded() {
        boolean expect = true;
        double currentAmount = user.getAmount();

        double actual = userService.addFund( 100);

        double delta = 0.0001;
        Assert.assertEquals(currentAmount + 100.0, actual, delta);
    }

    @Test
    void shouldThrowException_WhenAmountIsZeroOrNegative() {

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> userService.addFund(0));

        assertEquals("Amount must be greater than 0", exception.getMessage());
    }

    @Test
    void shouldCreateBill_WhenBillIsValid() {
        Bill bill = new Bill(1, "E", 80.0, new Date(), false, "VNPT");
        Bill created = billService.createBill(bill);

        assertEquals(bill, created);
        assertEquals(bill, billService.viewBill(1));
    }

    @Test
    void shouldThrowException_WhenUpdatingNonexistentBill() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> billService.updateBill(99,
                        new Bill(99, "E", 80.0, new Date(), false, "VNPT")));

        assertEquals("Bill not found", exception.getMessage());
    }

    @Test
    void shouldDeleteBill_WhenBillExists() {
        Bill bill = new Bill(99, "E", 80.0, new Date(), false, "VNPT");
        billService.createBill(bill);

        assertTrue(billService.delete(bill));
        assertThrows(IllegalArgumentException.class, () -> billService.viewBill(1));
    }

    @Test
    void shouldReturnFalse_WhenDeletingNonexistentBill() {
        Bill bill = new Bill(99, "E", 80.0, new Date(), false, "VNPT");
        assertFalse(billService.delete(bill));
    }

    @Test
    void shouldReturnUnpaidBillsOnly() {
        Bill paidBill = new Bill(1, "A", 120.50, new Date(), true, "VNPT");
        Bill unpaidBill1 = new Bill(2, "B", 80.00, new Date(), false, "VNPT");
        Bill unpaidBill2 = new Bill(3, "C", 50.00, new Date(), false, "VNPT");

        billService.createBill(paidBill);
        billService.createBill(unpaidBill1);
        billService.createBill(unpaidBill2);

        List<Bill> unpaidBills = billService.trackByDueDate();

        assertEquals(2, unpaidBills.size());
        assertTrue(unpaidBills.contains(unpaidBill1));
        assertTrue(unpaidBills.contains(unpaidBill2));
    }
}
