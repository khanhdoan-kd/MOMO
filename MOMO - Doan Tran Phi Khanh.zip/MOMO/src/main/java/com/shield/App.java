package com.shield;

import com.shield.entity.Bill;
import com.shield.services.BillService;
import com.shield.services.IUserService;

import java.util.List;
import java.util.Scanner;

public class App {

    private BillService billService;
    private IUserService userService;

    public App(BillService billService, IUserService userService) {
        this.billService = billService;
        this.userService = userService;
    }

    public void doApp() {
        Scanner scanner = new Scanner(System.in);;

        while (true) {
            System.out.println("\n===== BILL MANAGEMENT SYSTEM =====");
            System.out.println("1. Add Fund");
            System.out.println("2. View Unpaid Bills");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1: addFund();
                case 2: viewUnpaidBills();
                case 3: {
                    System.out.println("Exiting");
                    System.exit(0);
                }
                default:
                    System.out.println("Invalid choice! Please enter a valid number");
            }
        }
    }

    private void addFund() {
        System.out.println("Add your amount");
        Scanner scanner = new Scanner(System.in);
        try {
            int amount = scanner.nextInt();
            userService.addFund(amount);
            System.out.println("New fund: " + userService.getUser().getAmount());
        }
        catch (Exception e) {
            System.out.println("Invalid amount! Please enter a valid number");
        }
    }

    private void viewUnpaidBills() {
        List<Bill> bills = billService.trackByDueDate();
        bills.forEach(bill -> {
            System.out.println(bill.toString());
        });
    }
}
