package com.shield;

import com.shield.entity.Bill;
import com.shield.entity.User;
import com.shield.services.BillService;
import com.shield.services.IBillService;
import com.shield.services.IUserService;
import com.shield.services.UserService;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        List<Bill> bills = new ArrayList<>();
        BillService billService = new BillService(bills);
        User user = new User();
        IUserService userService = new UserService(user);

        Bill paidBill = new Bill(1, "A", 120.50, new Date(), true, "VNPT");
        Bill unpaidBill1 = new Bill(2, "B", 80.00, new Date(), false, "VNPT");
        Bill unpaidBill2 = new Bill(3, "C", 50.00, new Date(), false, "VNPT");

        billService.createBill(paidBill);
        billService.createBill(unpaidBill1);
        billService.createBill(unpaidBill2);

        App app = new App(billService, userService);
        app.doApp();
    }


}