package com.shield.services;

import com.shield.entity.Bill;
import com.shield.entity.User;

import java.util.List;

public interface IBillService {

    Bill createBill(Bill bill);

    boolean delete(Bill bill);

    Bill updateBill(int id, Bill bill);

    Bill viewBill(int id);

    double pay(User userId, int billId);

    List<Bill> trackByDueDate();
}
