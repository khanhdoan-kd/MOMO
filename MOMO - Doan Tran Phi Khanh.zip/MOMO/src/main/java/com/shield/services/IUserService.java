package com.shield.services;

import com.shield.entity.User;

public interface IUserService {

    User getUser();
    double addFund(double amount);
}
