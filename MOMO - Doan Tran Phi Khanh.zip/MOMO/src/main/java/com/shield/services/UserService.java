package com.shield.services;

import com.shield.entity.User;

public class UserService implements IUserService {

    private User user;
    public UserService(User user) {
        this.user = user;
    }

    @Override
    public User getUser() {
        return this.user;
    }

    @Override
    public double addFund(double amount) {
        if (amount < 1) {
            throw new IllegalArgumentException("Amount must be greater than 0");
        }
        user.setAmount(amount);
        return user.getAmount();
    }
}
