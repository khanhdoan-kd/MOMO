package com.shield.services;

import com.shield.entity.Bill;
import com.shield.entity.User;

import java.util.List;
import java.util.stream.Collectors;

public class BillService implements IBillService {

    private List<Bill> bills;

    public BillService(List<Bill> bills) {
        this.bills = bills;
    }

    @Override
    public Bill createBill(Bill newBill) {
        for (Bill bill : bills) {
            if(bill.getId() == newBill.getId()) {
                throw new IllegalArgumentException("Bill already exists");
            }
        }
        bills.add(newBill);
        return newBill;
    }

    @Override
    public boolean delete(Bill bill) {
        boolean isDelete = bills.remove(bill);
        return isDelete;
    }

    @Override
    public Bill updateBill(int id, Bill bill) {
        for (Bill b : bills) {
            if (b.getId() == id) {
                b = bill;
                return b;
            }
        }
        throw new IllegalArgumentException("Bill not found");
    }

    @Override
    public Bill viewBill(int id) {
        for (Bill b : bills) {
            if (b.getId() == id) {
                return b;
            }
        }
        throw new IllegalArgumentException("Bill not found");
    }

    @Override
    public double pay(User user, int billId) {
        Bill bill = null;
        for (Bill b : bills) {
            if (b.getId() == billId) {
                bill = b;
                break;
            }
        }
        if (bill == null) {
            throw new IllegalArgumentException("Bill not found");
        }

        if (user.getAmount() < bill.getAmount()) {
            throw new IllegalArgumentException("User amount is less than bill amount");
        }
        user.setAmount(user.getAmount() - bill.getAmount());
        return user.getAmount();
    }

    public List<Bill> trackByDueDate() {
        return bills.stream()
                .filter(bill -> !bill.isState())
                .collect(Collectors.toList());
    }
}
