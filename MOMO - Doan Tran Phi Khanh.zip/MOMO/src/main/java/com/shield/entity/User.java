package com.shield.entity;

public class User {

    private double amount;

    public User() {

    }

    public User(double amount) {
        this.amount = amount;
    }

    public double getAmount() {return this.amount;}

    public void setAmount(double amount) {this.amount = amount;}

}
