package com.shield.entity;

import java.util.Date;
import java.util.Objects;

public class Bill {
    private int id;
    private String type;
    private double amount;
    private Date dueDate;
    private boolean state;
    private String provider;
    private int userId;

    public Bill(int id, String type, double amount, Date dueDate, boolean state, String provider) {
        this.id = id;
        this.type = type;
        this.amount = amount;
        this.dueDate = dueDate;
        this.state = state;
        this.provider = provider;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getAmount() {
        return amount;
    };

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public boolean isState() {
        return this.state;
    }

    @Override
    public String toString() {
        return "Bill{" +
                "id=" + id +
                ", type='" + type + '\'' +
                ", amount=" + amount +
                ", dueDate=" + dueDate +
                ", state=" + state +
                ", provider='" + provider + '\'' +
                '}';
    }
}
